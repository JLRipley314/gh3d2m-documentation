#include <stdio.h>
#include <stdlib.h>
#include <rpc/rpc.h>
#include <string.h>
#include "rvs.h"
#include "rvs_cli.h"
#define  ON   1
#define  OFF  0
