#ifndef BBH_TYPES_DEF
#define BBH_TYPES_DEF

typedef void BBH_V;
typedef int BBH_I;
typedef char BBH_C;
typedef double BBH_D;

#endif
