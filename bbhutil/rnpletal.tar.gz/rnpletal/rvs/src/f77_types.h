#ifndef F77DEF
#define F77DEF

typedef  int      *   Pint;
typedef  int      *   INTEGER;

typedef  float    *   Pfloat;
typedef  float    *   REAL;

typedef  double   *   Pdouble;
typedef  double   *   REAL8;

typedef  char     *   Pchar;
typedef  char     *   CHARACTER;

#endif
