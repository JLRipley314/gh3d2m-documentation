float ETIME() {
	return 0;
}
