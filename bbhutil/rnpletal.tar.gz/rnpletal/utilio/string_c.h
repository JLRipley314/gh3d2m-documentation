#ifndef STRING_C_DEF
#define STRING_C_DEF

extern    char      *sskiplb(char *string);
extern    char      *str2lc(char *str_in);
extern    char      *str2f77id(char *str_in);
extern    char      *str2anu(char *str_in);

#endif
