#ifndef DEFUTILEXPLORER_C
#define DEFUTILEXPLORER_C

extern     void   spherical_to_XYZ3DData0(char *fname,double *vf,double *vr,
                                          int nr,
                                          double thmin,double thmax,int nth,
                                          double phmin,double phmax,int nph);
extern     int    fuzzeq(double f1,double f2);

#endif  
