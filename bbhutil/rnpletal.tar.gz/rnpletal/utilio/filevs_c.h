#ifndef FILEVS_CDEF
#define FILEVS_CDEF

extern    int       vsxynt(char *name,double t,DVEC x,DVEC y,int n);

#endif
