#ifndef IMATLIB_DEF
#define IMATLIB_DEF

extern    void       imma_();
extern    void       imms_();
extern    void       immm_();
extern    void       immd_();
extern    void       imls_();
extern    void       imdump_();
extern    void       imrlod_();
extern    void       imrsto_();
extern    void       imimsa_();
extern    void       imcopy_();
extern    void       imramp_();
extern    void       imfapl_();
extern    int        imsum_();
extern    int        immin_();
extern    int        immax_();
extern    int        imlinf_();
extern    void       imwritefr_();
extern    void       imreadfr_();

#endif
