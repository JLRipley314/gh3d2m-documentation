#ifndef _DS_TYPESDEF
#define _DS_TYPESDEF

#include "v_types.h"

typedef struct     DSEG {
   double     x0;
   double     x1;
}                  DSEG, *PDSEG;

#endif
