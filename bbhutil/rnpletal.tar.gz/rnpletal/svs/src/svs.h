#ifndef HVS_DEF
#define HVS_DEF

extern int vsxynt(const char *name,double t,double *x,double *y,int n);
extern int xvs(const char *name,double t,double *x,double *y,int n);

#endif
