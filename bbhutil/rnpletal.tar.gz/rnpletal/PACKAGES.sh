PACKAGES="\
   rvs \
   cliser \
   rnpl \
   svs \
   vutil \
   utilmath \
   visutil \
   utilio \
   cvtestsdf \
   netlib_linpack \
   netlib_odepack \
   netlib_fftpack \
   netlib_lapack3.0 \
"
